export { default as Auth } from './Auth';
export { default as Dashboard } from './Dashboard';
export { default as DocumentEditor } from './DocumentEditor';
export { default as Settings } from './Settings';
export { default as Templates } from './Templates';