/*
  # Fix Document Policies with Materialized View

  1. Changes
    - Create materialized view for shared documents
    - Simplify policies to eliminate recursion
    - Add refresh function for materialized view
  
  2. Security
    - Maintain row-level security
    - Ensure proper access control
    - Prevent any recursive policy checks
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "documents_read_policy" ON documents;
DROP POLICY IF EXISTS "documents_insert_policy" ON documents;
DROP POLICY IF EXISTS "documents_update_policy" ON documents;
DROP POLICY IF EXISTS "documents_delete_policy" ON documents;

-- Create materialized view for shared documents
CREATE MATERIALIZED VIEW shared_document_access AS
SELECT DISTINCT
  document_id,
  shared_with
FROM document_shares;

CREATE INDEX idx_shared_document_access ON shared_document_access(document_id, shared_with);

-- Create function to refresh materialized view
CREATE OR REPLACE FUNCTION refresh_shared_document_access()
RETURNS TRIGGER AS $$
BEGIN
  REFRESH MATERIALIZED VIEW CONCURRENTLY shared_document_access;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to refresh view when shares change
CREATE TRIGGER refresh_shared_document_access_trigger
AFTER INSERT OR UPDATE OR DELETE ON document_shares
FOR EACH STATEMENT
EXECUTE FUNCTION refresh_shared_document_access();

-- Create new simplified policies
CREATE POLICY "documents_owner_access"
  ON documents
  USING (user_id = auth.uid());

-- Create separate policies for each operation
CREATE POLICY "documents_insert"
  ON documents
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "documents_update"
  ON documents
  FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "documents_delete"
  ON documents
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Create policy for shared access using materialized view
CREATE POLICY "documents_shared_access"
  ON documents
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM shared_document_access
      WHERE document_id = documents.id
      AND shared_with = auth.uid()
    )
  );